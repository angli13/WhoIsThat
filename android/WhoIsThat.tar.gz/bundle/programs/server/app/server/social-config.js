(function(){ServiceConfiguration.configurations.remove({
    service: 'facebook'
});
 
ServiceConfiguration.configurations.insert({
    service: 'facebook',
    appId: '719593914817321',
    secret: 'ae620c315389781a9ff982bdf1fbb032'
});

ServiceConfiguration.configurations.remove({
  service: "twitter"
});
ServiceConfiguration.configurations.insert({
  service: "twitter",
  consumerKey: "l1LAD29dgWyF55wOUvau5Ss3q",
  secret: "76sRIpaxdps6r0re4qGjliCs12HzFUjkd9okGIFe95F19b2Hvm"
});

})();
