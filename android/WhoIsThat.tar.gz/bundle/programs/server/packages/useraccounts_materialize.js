(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
var Accounts = Package['accounts-base'].Accounts;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Router = Package['iron:router'].Router;
var RouteController = Package['iron:router'].RouteController;
var Iron = Package['iron:core'].Iron;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['useraccounts:materialize'] = {};

})();

//# sourceMappingURL=useraccounts_materialize.js.map
